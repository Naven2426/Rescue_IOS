import SwiftUI

struct ChangePasswordView: View {
    @State private var currentPassword: String = ""
    @State private var newPassword: String = ""
    @State private var confirmPassword: String = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {

                // Header
                HStack {
                    Button(action: {
                        // Back button action
                    }) {
                        Image("backarrow")
                            .resizable()
                            .frame(width: 30, height: 30)
                            .padding(.leading, 40)
                            .padding(.top, 56)
                    }

                    Text("Change Password")
                        .font(.system(size: 25, weight: .bold))
                        .foregroundColor(.black)
                        .padding(.top, 52)
                        .padding(.leading, 16)

                    Spacer()
                }
                .frame(height: 142)

                // Current Password
                Group {
                    Text("Current Password")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.black)
                        .padding(.leading, 30)
                        .padding(.top, 30)

                    SecureField("Enter current password", text: $currentPassword)
                        .padding(.horizontal, 10)
                        .frame(width: 350, height: 50)
                        .background(Color.white)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray))
                        .cornerRadius(8)
                        .frame(maxWidth: .infinity, alignment: .center)
                }

                // New Password
                Group {
                    Text("Password")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.black)
                        .padding(.leading, 30)
                        .padding(.top, 5)

                    SecureField("Enter new password", text: $newPassword)
                        .padding(.horizontal, 10)
                        .frame(width: 350, height: 50)
                        .background(Color.white)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray))
                        .cornerRadius(8)
                        .frame(maxWidth: .infinity, alignment: .center)
                }

                // Confirm Password
                Group {
                    Text("Confirm Password")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.black)
                        .padding(.leading, 30)
                        .padding(.top, 5)

                    SecureField("Re-enter new password", text: $confirmPassword)
                        .padding(.horizontal, 10)
                        .frame(width: 350, height: 50)
                        .background(Color.white)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.gray))
                        .cornerRadius(8)
                        .frame(maxWidth: .infinity, alignment: .center)
                }

                // Save Button
                Button(action: {
                    // Save password logic
                }) {
                    Text("Save Password")
                        .font(.system(size: 18, weight: .bold))
                        .frame(width: 350, height: 50)
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding(.top, 80)
                .padding(.bottom, 30)
                .frame(maxWidth: .infinity, alignment: .center)
            }
        }
        .background(Color("lightsandal").ignoresSafeArea())
    }
}

struct ChangePasswordView_Previews: PreviewProvider {
    static var previews: some View {
        ChangePasswordView()
    }
}
