import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
            
            AlertHistoryView()
                .tabItem {
                    Image(systemName: "clock.fill")
                    Text("History")
                }
            
            ProfileView()
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("Profile")
                }
        }
        .accentColor(.blue)
    }
}

struct HomeView: View {
    @State private var location: String = "Chennai"
    @State private var isLoading: Bool = false

    let columns: [GridItem] = Array(repeating: .init(.flexible()), count: 3)

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Image("alert")
                    .resizable()
                    .frame(width: 168, height: 166)
                    .padding(.top, 20)

                Text("Tap in case of emergency")
                    .fontWeight(.bold)
                    .foregroundColor(.black)
                    .padding(.top, 24)

                if !isLoading {
                    LazyVGrid(columns: columns, spacing: 16) {
                        ForEach(0..<5) { index in
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color.gray.opacity(0.1))
                                .frame(width: 105, height: 99)
                                .overlay(Text("Agency Item \(index + 1)").foregroundColor(.black))
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 70)
                    .padding(.top, 24)
                }
            }
        }
        .background(Color("lightsandal").ignoresSafeArea())
    }
}

struct AlertHistoryView: View {
    let allAlerts: [AlertItem] = [
        AlertItem(status: "Accepted", alertType: "Medical", dateSent: "2024-05-20"),
        AlertItem(status: "Rejected", alertType: "Fire", dateSent: "2024-04-10"),
        AlertItem(status: "Accepted", alertType: "Medical", dateSent: "2024-04-09"),
        AlertItem(status: "Rejected", alertType: "Medical", dateSent: "2024-03-05"),
        AlertItem(status: "Accepted", alertType: "Medical", dateSent: "2024-03-05")
    ]
    
    @State private var selectedTab = 0
    
    var recentAlerts: [AlertItem] {
        Array(allAlerts.prefix(2))
    }
    
    var body: some View {
        NavigationView {
            VStack {
                Picker("View Selection", selection: $selectedTab) {
                    Text("Check Status").tag(0)
                    Text("History").tag(1)
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding(.horizontal)
                .padding(.top)
                
                List(selectedTab == 0 ? recentAlerts : allAlerts) { alert in
                    AlertItemView(alert: alert)
                }
                .listStyle(PlainListStyle())
            }
            .navigationTitle(selectedTab == 0 ? "Check Status" : "History")
        }
    }
}

struct ProfileView: View {
    var body: some View {
        ScrollView {
            VStack(spacing: 30) {
                // Top Profile Card
                ZStack(alignment: .topTrailing) {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color("sandal"))
                        .frame(height: 270)
                        .shadow(radius: 10)

                    VStack(spacing: 16) {
                        Spacer().frame(height: 30)

                        Image("profilename")
                            .resizable()
                            .frame(width: 100, height: 100)
                            .clipShape(Circle())

                        HStack(spacing: 16) {
                            Button(action: {
                                // Update Profile Action
                            }) {
                                Text("Update Profile")
                                    .font(.system(size: 14, weight: .bold))
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 10)
                                    .background(Color("roundstyle2"))
                                    .foregroundColor(.black)
                                    .cornerRadius(20)
                            }

                            Button(action: {
                                // Change Password Action
                            }) {
                                Text("Change Password")
                                    .font(.system(size: 14, weight: .bold))
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 10)
                                    .background(Color("roundstyle2"))
                                    .foregroundColor(.black)
                                    .cornerRadius(20)
                            }
                        }
                        .padding(.horizontal)

                        Spacer()
                    }
                    .padding(.top)

                    Button(action: {
                        // Logout Action
                    }) {
                        Image("logout")
                            .resizable()
                            .frame(width: 27, height: 27)
                            .padding(.top, 40)
                            .padding(.trailing, 38)
                    }
                }

                // Account Info
                VStack(alignment: .leading, spacing: 24) {
                    Text("Account Info")
                        .font(.system(size: 30, weight: .bold))
                        .foregroundColor(.black)
                        .padding(.leading, -10)

                    ProfileItem(imageName: "profilename", label: "Name", value: "Mark")
                    ProfileItem(imageName: "mobile", label: "Mobile", value: "9876543210")
                    ProfileItem(imageName: "email", label: "Email", value: "markexa123@gmail.com")
                    ProfileItem(imageName: "dob", label: "Date of Birth", value: "12-05-2000")
                    ProfileItem(imageName: "address", label: "Address", value: "123, Main Street, Chennai")
                }

                Spacer()
            }
            .padding()
            .background(Color("lightsandal").edgesIgnoringSafeArea(.all))
        }
    }
}

struct ProfileItem: View {
    let imageName: String
    let label: String
    let value: String

    var body: some View {
        HStack(alignment: .top) {
            Image(imageName)
                .resizable()
                .frame(width: 40, height: 40)

            VStack(alignment: .leading, spacing: 4) {
                Text(label)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.black)

                Text(value)
                    .font(.system(size: 17))
                    .foregroundColor(.black)
            }
            .padding(.leading, 10)
        }
        .padding(.horizontal)
    }
}

struct AlertItem: Identifiable {
    let id = UUID()
    let status: String
    let alertType: String
    let dateSent: String
}

struct AlertItemView: View {
    let alert: AlertItem
    
    var statusColor: Color {
        alert.status == "Accepted" ? .green : .red
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Status: ")
                    .font(.system(size: 16, weight: .regular)) +
                Text(alert.status)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(statusColor)
                Spacer()
            }
            
            HStack {
                Text("Alert Type: \(alert.alertType)")
                    .font(.system(size: 16, weight: .regular))
                Spacer()
            }
            
            HStack {
                Text("Date Sent: \(alert.dateSent)")
                    .font(.system(size: 16, weight: .regular))
                Spacer()
            }
        }
        .padding(.vertical, 12)
    }
}

struct MainTabView_Previews: PreviewProvider {
    static var previews: some View {
        MainTabView()
    }
}
