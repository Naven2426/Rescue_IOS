import SwiftUI
import MapKit
import CoreLocation

struct NewRequestInfoView: View {
    @State private var descriptionText: String = ""
    @State private var selectedImage: UIImage? = nil
    @State private var showImagePicker = false
    @State private var showImageSourcePicker = false
    @State private var showMapView = false
    @State private var selectedLocation: CLLocationCoordinate2D?
    @State private var imageSourceType: UIImagePickerController.SourceType = .photoLibrary
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // Header with Back Button
                    HStack {
                        Button(action: {
                            // Handle back action
                        }) {
                            Image("backarrow")
                                .resizable()
                                .frame(width: 24, height: 24)
                                .padding(.leading, 40)
                        }
                        
                        Spacer()
                        
                        Text("New Request Info")
                            .font(.system(size: 18, weight: .bold))
                        
                        Spacer()
                        
                        // Empty view for balance
                        Image(systemName: "arrow.left")
                            .resizable()
                            .frame(width: 24, height: 24)
                            .padding(.leading, 20)
                            .hidden()
                    }
                    .padding(.top, 20)
                    
                    // Rescue Team Section
                    VStack(alignment: .leading, spacing: 15) {
                        Text("Rescue Team")
                            .font(.system(size: 18, weight: .bold))
                            .padding(.leading, 20)
                        
                        // Choose Rescue Agency Button - Opens Map
                        Button(action: {
                            showMapView = true
                        }) {
                            HStack {
                                Text(selectedLocation == nil ? "Choose Rescue Agency" : "Location Selected")
                                    .foregroundColor(selectedLocation == nil ? .gray : .green)
                                Spacer()
                                Image(systemName: "mappin.and.ellipse")
                                    .foregroundColor(.gray)
                            }
                            .padding()
                            .frame(height: 50)
                            .background(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.gray, lineWidth: 1)
                            )
                        }
                        .padding(.horizontal, 20)
                        .sheet(isPresented: $showMapView) {
                            MapSelectionView(selectedLocation: $selectedLocation)
                        }
                        
                        // Describe Section
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Describe")
                                .font(.system(size: 18, weight: .bold))
                            
                            TextEditor(text: $descriptionText)
                                .frame(height: 120)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.gray, lineWidth: 1)
                                )
                                .padding(.bottom, 10)
                        }
                        .padding(.horizontal, 20)
                        
                        // Proof Section with Camera/Gallery Selection
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Proof")
                                .font(.system(size: 18, weight: .bold))
                            
                            Button(action: {
                                showImageSourcePicker = true
                            }) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.gray, lineWidth: 1)
                                        .frame(height: 150)
                                    
                                    if let image = selectedImage {
                                        Image(uiImage: image)
                                            .resizable()
                                            .scaledToFill()
                                            .frame(height: 150)
                                            .clipped()
                                            .cornerRadius(10)
                                    } else {
                                        VStack {
                                            Image(systemName: "photo")
                                                .font(.system(size: 40))
                                                .foregroundColor(.gray)
                                            Text("Add proof image")
                                                .foregroundColor(.gray)
                                        }
                                    }
                                }
                            }
                            .actionSheet(isPresented: $showImageSourcePicker) {
                                ActionSheet(
                                    title: Text("Select Image Source"),
                                    buttons: [
                                        .default(Text("Take Photo")) {
                                            imageSourceType = .camera
                                            showImagePicker = true
                                        },
                                        .default(Text("Choose from Gallery")) {
                                            imageSourceType = .photoLibrary
                                            showImagePicker = true
                                        },
                                        .cancel()
                                    ]
                                )
                            }
                        }
                        .padding(.horizontal, 20)
                    }
                    
                    // Submit Button
                    Button(action: {
                        if let location = selectedLocation {
                            openInGoogleMaps(coordinate: location)
                        }
                    }) {
                        Text("Submit")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 50)
                            .background(Color.green)
                            .cornerRadius(10)
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    .padding(.bottom, 40)
                    .disabled(selectedLocation == nil)
                }
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showImagePicker) {
                ImagePicker(image: $selectedImage, sourceType: imageSourceType)
            }
        }
    }
    
    func openInGoogleMaps(coordinate: CLLocationCoordinate2D) {
        let urlString = "comgooglemaps://?q=\(coordinate.latitude),\(coordinate.longitude)"
        
        if let url = URL(string: urlString) {
            if UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            } else {
                // If Google Maps is not installed, open in Apple Maps
                let placemark = MKPlacemark(coordinate: coordinate)
                let mapItem = MKMapItem(placemark: placemark)
                mapItem.name = "Selected Location"
                mapItem.openInMaps(launchOptions: nil)
            }
        }
    }
}

struct IdentifiableCoordinate: Identifiable {
    let id = UUID()
    var coordinate: CLLocationCoordinate2D
}

struct MapSelectionView: View {
    @Binding var selectedLocation: CLLocationCoordinate2D?
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 37.7749, longitude: -122.4194),
        span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
    )
    @Environment(\.presentationMode) var presentationMode
    
    private var annotationItems: [IdentifiableCoordinate] {
        if let location = selectedLocation {
            return [IdentifiableCoordinate(coordinate: location)]
        }
        return []
    }
    
    var body: some View {
        ZStack(alignment: .topTrailing) {
            // Map View
            Map(
                coordinateRegion: $region,
                interactionModes: .all,
                showsUserLocation: true,
                userTrackingMode: nil,
                annotationItems: annotationItems
            ) { item in
                MapMarker(coordinate: item.coordinate, tint: .red)
            }
            .edgesIgnoringSafeArea(.all)
            .onTapGesture {
                selectedLocation = region.center
            }
            
            // Cancel Button
            Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 30))
                    .foregroundColor(.white)
                    .background(Color.black.opacity(0.7))
                    .clipShape(Circle())
            }
            .padding(20)
            
            // Confirm Button
            VStack {
                Spacer()
                
                HStack {
                    Spacer()
                    
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Text("Confirm")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, 30)
                    .disabled(selectedLocation == nil)
                    .opacity(selectedLocation == nil ? 0.5 : 1)
                }
            }
        }
    }
}

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    var sourceType: UIImagePickerController.SourceType
    @Environment(\.presentationMode) var presentationMode
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = sourceType
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    
    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: ImagePicker
        
        init(_ parent: ImagePicker) {
            self.parent = parent
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let uiImage = info[.originalImage] as? UIImage {
                parent.image = uiImage
            }
            parent.presentationMode.wrappedValue.dismiss()
        }
    }
}

struct NewRequestInfoView_Previews: PreviewProvider {
    static var previews: some View {
        NewRequestInfoView()
    }
}
