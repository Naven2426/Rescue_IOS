//import SwiftUI
//
//struct AlertHistoryView: View {
//    // Sample data with status that can be "Accepted" or "Rejected"
//    let allAlerts: [AlertItem] = [
//        AlertItem(status: "Accepted", alertType: "Medical", dateSent: "2024-05-20"),
//        AlertItem(status: "Rejected", alertType: "Fire", dateSent: "2024-04-10"),
//        AlertItem(status: "Accepted", alertType: "Medical", dateSent: "2024-04-09"),
//        AlertItem(status: "Rejected", alertType: "Medical", dateSent: "2024-03-05"),
//        AlertItem(status: "Accepted", alertType: "Medical", dateSent: "2024-03-05")
//    ]
//    
//    @State private var selectedTab = 0
//    
//    // Get only the first two alerts for Check Status
//    var recentAlerts: [AlertItem] {
//        Array(allAlerts.prefix(1))
//    }
//    
//    var body: some View {
//        NavigationView {
//            VStack {
//                // Segmented Control
//                Picker("View Selection", selection: $selectedTab) {
//                    Text("Check Status").tag(0)
//                    Text("History").tag(1)
//                }
//                .pickerStyle(SegmentedPickerStyle())
//                .padding(.horizontal)
//                .padding(.top)
//                
//                // Content based on selected tab
//                List(selectedTab == 0 ? recentAlerts : allAlerts) { alert in
//                    AlertItemView(alert: alert)
//                }
//                .listStyle(PlainListStyle())
//            }
//            .navigationTitle(selectedTab == 0 ? "Check Status" : "History")
//        }
//    }
//}
//
//struct AlertItem: Identifiable {
//    let id = UUID()
//    let status: String  // "Accepted" or "Rejected"
//    let alertType: String
//    let dateSent: String
//}
//
//struct AlertItemView: View {
//    let alert: AlertItem
//    
//    var statusColor: Color {
//        alert.status == "Accepted" ? .green : .red
//    }
//    
//    var body: some View {
//        VStack(alignment: .leading, spacing: 8) {
//            HStack {
//                Text("Status: ")
//                    .font(.system(size: 16, weight: .regular)) +
//                Text(alert.status)
//                    .font(.system(size: 16, weight: .bold))
//                    .foregroundColor(statusColor)
//                Spacer()
//            }
//            
//            HStack {
//                Text("Alert Type: \(alert.alertType)")
//                    .font(.system(size: 16, weight: .regular))
//                Spacer()
//            }
//            
//            HStack {
//                Text("Date Sent: \(alert.dateSent)")
//                    .font(.system(size: 16, weight: .regular))
//                Spacer()
//            }
//        }
//        .padding(.vertical, 12)
//    }
//}
//
//struct AlertHistoryView_Previews: PreviewProvider {
//    static var previews: some View {
//        AlertHistoryView()
//    }
//}
