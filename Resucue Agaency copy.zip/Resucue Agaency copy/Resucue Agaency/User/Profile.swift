//import SwiftUI
//
//struct ProfileView: View {
//    var body: some View {
//        ScrollView {
//            VStack(spacing: 30) {
//                
//                // Top Profile Card
//                ZStack(alignment: .topTrailing) {
//                    RoundedRectangle(cornerRadius: 10)
//                        .fill(Color("sandal"))
//                        .frame(height: 270)
//                        .shadow(radius: 10)
//
//                    VStack(spacing: 16) {
//                        Spacer().frame(height: 30)
//
//                        Image("profilename")
//                            .resizable()
//                            .frame(width: 100, height: 100)
//                            .clipShape(Circle())
//
//                        HStack(spacing: 16) {
//                            Button(action: {
//                                // Update Profile Action
//                            }) {
//                                Text("Update Profile")
//                                    .font(.system(size: 14, weight: .bold))
//                                    .frame(maxWidth: .infinity)
//                                    .padding(.vertical, 10)
//                                    .background(Color("roundstyle2"))
//                                    .foregroundColor(.black)
//                                    .cornerRadius(20)
//                            }
//
//                            Button(action: {
//                                // Change Password Action
//                            }) {
//                                Text("Change Password")
//                                    .font(.system(size: 14, weight: .bold))
//                                    .frame(maxWidth: .infinity)
//                                    .padding(.vertical, 10)
//                                    .background(Color("roundstyle2"))
//                                    .foregroundColor(.black)
//                                    .cornerRadius(20)
//                            }
//                        }
//                        .padding(.horizontal)
//
//                        Spacer()
//                    }
//                    .padding(.top)
//
//                    Button(action: {
//                        // Logout Action
//                    }) {
//                        Image("logout")
//                            .resizable()
//                            .frame(width: 27, height: 27)
//                            .padding(.top, 40)
//                            .padding(.trailing, 38)
//                    }
//                }
//
//                // Account Info
//                VStack(alignment: .leading, spacing: 24) {
//                    Text("Account Info")
//                        .font(.system(size: 30, weight: .bold))
//                        .foregroundColor(.black)
//                        .padding(.leading,-10)
//
//                    ProfileItem(imageName: "profilename", label: "Name", value: "Mark")
//                    ProfileItem(imageName: "mobile", label: "Mobile", value: "9876543210")
//                    ProfileItem(imageName: "email", label: "Email", value: "markexa123@gmail.com")
//                    ProfileItem(imageName: "dob", label: "Date of Birth", value: "12-05-2000")
//                    ProfileItem(imageName: "address", label: "Address", value: "123, Main Street, Chennai")
//                }
//
//                Spacer()
//            }
//            .padding()
//            .background(Color("lightsandal").edgesIgnoringSafeArea(.all))
//        }
//    }
//}
//
//struct ProfileItem: View {
//    let imageName: String
//    let label: String
//    let value: String
//
//    var body: some View {
//        HStack(alignment: .top) {
//            Image(imageName)
//                .resizable()
//                .frame(width: 40, height: 40)
//
//            VStack(alignment: .leading, spacing: 4) {
//                Text(label)
//                    .font(.system(size: 20, weight: .bold))
//                    .foregroundColor(.black)
//
//                Text(value)
//                    .font(.system(size: 17))
//                    .foregroundColor(.black)
//            }
//            .padding(.leading, 10)
//        }
//        .padding(.horizontal)
//    }
//}
//
//struct ProfileView_Previews: PreviewProvider {
//    static var previews: some View {
//        ProfileView()
//    }
//}
