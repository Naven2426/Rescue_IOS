import SwiftUI

struct SignUpView: View {
    @State private var name = ""
    @State private var mobile = ""
    @State private var email = ""
    @State private var address = ""
    @State private var dob = ""
    @State private var selectedDate = Date()
    @State private var showDatePicker = false
    @State private var gender = "Male"

    let genders = ["Male", "Female"]

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                HStack {
                    Image("backarrow")
                        .resizable()
                        .frame(width: 30, height: 30)
                        .padding(.leading, 40)

                    Text("Update Profile")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.black)
                        .padding(.leading, 50)

                    Spacer()
                }
                .padding(.top, 40)

                CustomField(title: "Name", text: $name)
                CustomField(title: "Mobile", text: $mobile, keyboard: .phonePad)
                CustomField(title: "Email", text: $email, keyboard: .emailAddress)
                CustomField(title: "Address", text: $address)

                // D.O.B (Styled like other fields)
                VStack(alignment: .leading, spacing: 4) {
                    Text("D.O.B")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.black)
                        .padding(.leading, 16)

                    TextField("Select Date of Birth", text: $dob)
                        .disabled(true)
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 10).stroke(Color.gray))
                        .frame(height: 50)
                        .padding(.horizontal, 20)
                        .onTapGesture {
                            showDatePicker = true
                        }
                }

                // Gender
                VStack(alignment: .leading, spacing: 8) {
                    Text("Gender")
                        .font(.system(size: 18, weight: .bold))
                        .foregroundColor(.black)
                        .padding(.leading, 16)

                    HStack {
                        ForEach(genders, id: \.self) { item in
                            HStack {
                                Image(systemName: gender == item ? "largecircle.fill.circle" : "circle")
                                    .foregroundColor(gender == item ? .green : .gray)
                                    .onTapGesture { gender = item }

                                Text(item)
                                    .foregroundColor(.black)
                                    .onTapGesture { gender = item }
                            }
                            .padding(.trailing, 100)
                        }
                    }
                    .padding(.horizontal, 20)
                }

                Button(action: {
                    // Handle update
                }) {
                    Text("Update Profile")
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green)
                        .cornerRadius(10)
                }
                .padding(.horizontal, 20)
                .padding(.top, 30)
                .padding(.bottom, 60)
            }
        }
        .sheet(isPresented: $showDatePicker) {
            VStack {
                DatePicker("Select Date", selection: $selectedDate, displayedComponents: .date)
                    .datePickerStyle(.wheel)
                    .labelsHidden()
                    .padding()

                Button("Done") {
                    let formatter = DateFormatter()
                    formatter.dateFormat = "dd-MM-yyyy"
                    dob = formatter.string(from: selectedDate)
                    showDatePicker = false
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.green)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding(.horizontal)
            }
            .presentationDetents([.height(300)])
        }
    }
}

struct CustomField: View {
    var title: String
    @Binding var text: String
    var keyboard: UIKeyboardType = .default

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.black)
                .padding(.leading, 16)

            TextField("Enter \(title)", text: $text)
                .keyboardType(keyboard)
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).stroke(Color.gray))
                .frame(height: 50)
                .padding(.horizontal, 20)
        }
    }
}

struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView()
    }
}
