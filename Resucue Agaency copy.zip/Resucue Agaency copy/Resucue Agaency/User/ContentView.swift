import SwiftUI

struct LoginView: View {
    var body: some View {
        VStack {
            // Ellipse style background view
            Rectangle()
                .fill(Color("lightsandal"))
                .frame(height: 160)
                .overlay(
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(Color.blue, lineWidth: 2)
                )
                .padding(.bottom, 20)
            
            // Logo and Text
            HStack {
                Image("applogos")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 80)
                
                Text("RESCUE AGENCY")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.black)
                    .padding(.trailing, 30)
            }
            
            // Welcome Text
            VStack {
                Text("Welcome Back")
                    .font(.system(size: 30, weight: .bold))
                    .foregroundColor(.black)
                    .padding(.top, 15)
            }
            
            // User Name
            Text("User name")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.black)
                .padding(.top, 30)
                .padding(.leading, -170)
            
            TextField("Enter username", text: .constant(""))
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).strokeBorder(Color.gray, lineWidth: 1))
                .frame(width: 350, height: 50)
                .padding(.leading, 0)
            
            // Password
            Text("Password")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.black)
                .padding(.top, 30)
                .padding(.leading, -170)
            
            SecureField("Enter password", text: .constant(""))
                .padding()
                .background(RoundedRectangle(cornerRadius: 10).strokeBorder(Color.gray, lineWidth: 1))
                .frame(width: 350, height: 50)
                .padding(.leading, 0)
            
            // Sign Up Section
            HStack {
                Text("Don't have an Account?")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundColor(.black)
                
                Button(action: {
                    // Sign up action
                }) {
                    Text("Sign up")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundColor(.blue)
                }
            }
            .padding(.top, 24)
            
            // Login Button
            Button(action: {
                // Login action
            }) {
                Text("Login")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(width: 339, height: 50)
                    .background(RoundedRectangle(cornerRadius: 25).fill(Color.green))
            }
            .padding(.top, 75)
        }
        .padding()
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView()
    }
}
