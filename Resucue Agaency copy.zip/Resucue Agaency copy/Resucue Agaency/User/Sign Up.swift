import SwiftUI

struct Sign_Up: View {
    @State private var name = ""
    @State private var mobile = ""
    @State private var email = ""
    @State private var address = ""
    @State private var dob = Date()
    @State private var gender = ""
    @State private var username = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var showDatePicker = false

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                ZStack(alignment: .topLeading) {
                    Rectangle()
                        .fill(Color("lightsandal"))
                        .frame(height: 110)
                        .cornerRadius(50)
                        .overlay(Image("ellipsestyle").resizable())

                    HStack {
                        Button(action: {
                            // Back action
                        }) {
                            Image("backarrow")
                                .resizable()
                                .frame(width: 30, height: 30)
                                .padding(.leading, 30)
                                .padding(.top, 50)
                        }

                        Text("Sign up")
                            .font(.system(size: 25, weight: .bold))
                            .foregroundColor(Color.black)
                            .padding(.top, 48)
                            .padding(.leading, 90)
                    }
                }

                Group {
                    LabeledTextField(label: "Name", text: $name, placeholder: "Enter your name")
                    LabeledTextField(label: "Mobile", text: $mobile, keyboard: .phonePad, placeholder: "Enter your mobile number")
                    LabeledTextField(label: "Email", text: $email, keyboard: .emailAddress, placeholder: "Enter your email")
                    LabeledTextField(label: "Address", text: $address, placeholder: "Enter your address")

                    // D.O.B (Styled like other fields)
                    VStack(alignment: .leading) {
                        Text("Date of Birth")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(Color.black)
                            .padding(.leading, 30)

                        TextField("Select Date of Birth", text: Binding(
                            get: {
                                let formatter = DateFormatter()
                                formatter.dateFormat = "dd-MM-yyyy"
                                return formatter.string(from: dob)
                            },
                            set: { _ in }
                        ))
                            .disabled(true)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 10).stroke(Color.gray))
                            .padding(.horizontal)
                            .onTapGesture {
                                showDatePicker = true
                            }
                    }

                    VStack(alignment: .leading) {
                        Text("Gender")
                            .font(.system(size: 18, weight: .bold))
                            .foregroundColor(Color.black)
                            .padding(.leading, 0)

                        HStack {
                            RadioButton(title: "Male", selection: $gender)
                                .padding(.horizontal, 34) // Adjust padding for gap
                            RadioButton(title: "Female", selection: $gender)
                                .padding(.horizontal, 34) // Adjust padding for gap
                        }
                        .padding(.horizontal)
                    }

                    LabeledTextField(label: "Username", text: $username, placeholder: "Enter your username")
                    LabeledTextField(label: "Password", text: $password, isSecure: true, placeholder: "Enter your password")
                    LabeledTextField(label: "Confirm Password", text: $confirmPassword, isSecure: true, placeholder: "Confirm your password")
                }

                Button(action: {
                    // Sign up action
                }) {
                    Text("Sign Up")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .foregroundColor(.white)
                        .background(Color.green)
                        .cornerRadius(10)
                        .padding(.horizontal)
                }

                Spacer()
            }
        }
        .background(Color("lightsandal").ignoresSafeArea())
        .sheet(isPresented: $showDatePicker) {
            VStack {
                DatePicker("Select Date", selection: $dob, displayedComponents: .date)
                    .datePickerStyle(.wheel)
                    .labelsHidden()
                    .padding()

                Button("Done") {
                    let formatter = DateFormatter()
                    formatter.dateFormat = "dd-MM-yyyy"
                    showDatePicker = false
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.green)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding(.horizontal)
            }
            .presentationDetents([.height(300)])
        }
    }
}

struct LabeledTextField: View {
    var label: String
    @Binding var text: String
    var keyboard: UIKeyboardType = .default
    var isSecure: Bool = false
    var placeholder: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(label)
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(Color.black)
                .padding(.leading, 30)

            if isSecure {
                SecureField(placeholder, text: $text)
                    .padding(.horizontal, 10)
                    .frame(height: 50)
                    .background(RoundedRectangle(cornerRadius: 10).stroke(Color.gray))
                    .padding(.horizontal)
            } else {
                TextField(placeholder, text: $text)
                    .keyboardType(keyboard)
                    .padding(.horizontal, 10)
                    .frame(height: 50)
                    .background(RoundedRectangle(cornerRadius: 10).stroke(Color.gray))
                    .padding(.horizontal)
            }
        }
    }
}

struct RadioButton: View {
    var title: String
    @Binding var selection: String

    var body: some View {
        Button(action: {
            selection = title
        }) {
            HStack {
                Circle()
                    .stroke(Color.black, lineWidth: 2)
                    .frame(width: 20, height: 20)
                    .overlay(
                        Circle()
                            .fill(selection == title ? Color.green : Color.clear)
                            .frame(width: 12, height: 12)
                    )
                Text(title)
                    .font(.system(size: 20))
                    .foregroundColor(Color.black)
            }
        }
    }
}

#Preview {
    Sign_Up()
}
