//
//  Resucue_AgaencyApp.swift
//  Resucue Agaency
//
//  Created by SAIL L1 on 21/04/25.
//

import SwiftUI

@main
struct Resucue_AgaencyApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()        }
    }
}
